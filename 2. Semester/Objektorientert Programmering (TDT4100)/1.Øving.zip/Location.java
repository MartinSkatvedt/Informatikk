package stateandbehavior;

public class Location {
		public int cordinate[] = {0,0};
	
	public static void main(String[] args) {
		Location testLocation = new Location();
		System.out.println(testLocation.toString());
		testLocation.down();
		testLocation.left();
		System.out.println(testLocation.toString());
	}
	
	
	public void up() {
		this.cordinate[1] -= 1;
	}
	public void down() {
		this.cordinate[1] += 1;
	}
	public void left() {
		this.cordinate[0] -= 1;
	}
	public void right() {
		this.cordinate[0] += 1;
	}
	
	public int getX() {
		return this.cordinate[0];
	}
	
	public int getY() {
		return this.cordinate[1];
	}
	
	public String toString() {
		return "[x=" + this.cordinate[0] + " y=" + this.cordinate[1] + "]";
	}
	
	
	
	

}
