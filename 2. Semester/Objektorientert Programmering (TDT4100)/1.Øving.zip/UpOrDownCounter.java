package stateandbehavior;

public class UpOrDownCounter {
	public int start;
	public int stop;
	public int current;
	
	public static void main(String[] args) {}
	
	public UpOrDownCounter(int startArg, int stopArg) {
		this.checkArg(startArg, stopArg);
		this.start = startArg;
		this.stop = stopArg;
		this.current = this.start;
	}
	
	public void checkArg(int argValue1, int argValue2) throws IllegalArgumentException {
		if (argValue1 == argValue2) {
			throw new IllegalArgumentException("Start og stopp kan ikke v�re like");
		}
	}
	public int getCounter() {
		return this.current;
	}
	
	public boolean count() {
		if (this.current == this.stop) {
			return false;
		}
		
		if (this.start < this.stop) {
			this.current++;
		}
		else if (this.start > this.stop) {
			this.current--;
		}
		
	
		if (this.current == this.stop) {
			return false;
		}
		else return true;
	}
}
