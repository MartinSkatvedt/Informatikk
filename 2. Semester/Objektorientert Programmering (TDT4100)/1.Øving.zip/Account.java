package stateandbehavior;

public class Account {
	public double balance = 0;
	public double interestRate = 0;
	
	public static void main(String[] args) {
		Account testAccount = new Account();
		System.out.println(testAccount.toString());
		testAccount.deposit(100.0);
		testAccount.setInterestRate(10);
		testAccount.addInterest();
		System.out.println(testAccount.toString());
	}
	
	public void deposit(double addValue) {
		if (addValue > 0 ) {
			this.balance += addValue;
		}
	}
	
	public void addInterest() {
		this.balance += this.balance * (this.interestRate/100);
	}
	
	public double getBalance() {
		return this.balance;
	}
	
	public double getInterestRate() {
		return this.interestRate;
	}
	
	public void setInterestRate(double newInterestRate) {
		this.interestRate = newInterestRate;
	}
	
	public String toString() {
		return "[balance=" + this.balance + " interest rate=" + this.interestRate + "]";

	}
	
}
