package interfaces;

import java.util.Comparator;

public class CardComparator implements Comparator<Card> {
	private char trumf = ' ';
	private boolean countAce = false;
	private String SUITS;;

	
	public CardComparator(boolean argCountAce, char argTrumf) {
		this.trumf = argTrumf;
		this.countAce = argCountAce;

		this.SUITS =  this.trumf + "SHDC"; 
	}

	@Override
	public int compare(Card c1, Card c2) {
		
		int c1Value = SUITS.indexOf(c1.getSuit());
		int c2Value = SUITS.indexOf(c2.getSuit());

		if (c1Value > c2Value) return -1;
		if (c1Value == c2Value) {
			if (countAce && c1.getFace() == 1) return 1;
			if (countAce && c2.getFace() == 1) return -1;
			if (!countAce && c1.getFace() > c2.getFace()) return 1;
			if (!countAce && c1.getFace() < c2.getFace()) return -1;
			else return -1;
		}
		else return 1;
	}

}
