package interfaces;

import java.util.ArrayList;
import java.util.Iterator;

import objectstructures.Card;

public class CardContainerIterator implements Iterator<Card> {
	private ArrayList<Card> cards = new ArrayList<Card>();
	private int index = 0;

	public CardContainerIterator(CardContainer instance) {
		int n = instance.getCardCount();
		for (int i = 0; i < n; i++) {
			this.cards.add(instance.getCard(i));
		}
	}
	
	@Override
	 public boolean hasNext() {
	        return index < cards.size();
	 }
	
	@Override
	public Card next() {
	        Card c = cards.get(index);
	        index+=1;
	        return c;
	    }
	
	 @Override
	 public void remove() {
	        throw new UnsupportedOperationException("St�tter ikke remove");
	    }


}
