package interfaces;

import objectstructures.Card;

public interface CardContainer {
	
	public int getCardCount();
	
	public Card getCard(int n);
}
