package objectstructures;

import java.util.ArrayList;

public class CardHand {
	private ArrayList<Card> cards;
	
	public static void main(String[] args) {
		CardHand hand = new CardHand();
		CardDeck deck = new CardDeck(13);
		
		deck.shufflePerfectly();
		System.out.println(deck.toString());
		System.out.println(hand.toString());
		
		deck.deal(hand, 4);
		System.out.println(hand.toString());
		
		hand.play(0);
		System.out.println(hand.toString());
	}
	

	public CardHand() {
		cards = new ArrayList<Card>();
	}
	
	public int getCardCount() {
		return cards.size();
	}
	
	
	public Card getCard(int i) {
		if (i < 0 || i >= getCardCount()) {
			throw new IllegalArgumentException(String.format("%s is an illegal card index, when the size of the hand is %s", i, getCardCount()));
		}
		return cards.get(i);
	}
	
	public void addCard(Card argCard) {
		cards.add(argCard);
	}
	
	public Card play(int n) {
		return cards.remove(n);
	}
	
	@Override
	public String toString() {
		return "[Cards " + cards.toString().substring(1);
	}
	
}
