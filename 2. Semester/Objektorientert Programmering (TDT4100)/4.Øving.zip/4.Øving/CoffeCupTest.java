package objectstructures;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CoffeCupTest {
	
	private boolean checkState(CoffeeCup cup, double expectedCapacity, double expectedVolume) {
		if (cup.getCapacity() == expectedCapacity && cup.getCurrentVolume() == expectedVolume) return true;
		else return false;
	}
	
	@Test
	void testConstructor() {
		Assertions.assertTrue(checkState(new CoffeeCup(40, 20), 40, 20));
		Assertions.assertTrue(checkState(new CoffeeCup(40.0, 20.0), 40.0, 20.0));
		
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new CoffeeCup(-1, 20);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new CoffeeCup(40, -1);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new CoffeeCup(10, 20);
		});
		
		
	}
	
	@Test
	void testIncreaseCupSize() {
		CoffeeCup testCup = new CoffeeCup(40,20);
		testCup.increaseCupSize(100);
		Assertions.assertTrue(checkState(testCup, 140, 20));
		
		testCup.increaseCupSize(-100);
		Assertions.assertTrue(checkState(testCup, 140, 20));
	}
	
	@Test
	void testDrinkCoffe() {
		CoffeeCup testCup = new CoffeeCup(40,20);
		testCup.drinkCoffee(10);	
		Assertions.assertTrue(checkState(testCup, 40, 10));
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			testCup.drinkCoffee(20);
		});
	}
	
	@Test
	void testFillCoffee() {
		CoffeeCup testCup = new CoffeeCup(40,20);
		testCup.fillCoffee(10);
		Assertions.assertTrue(checkState(testCup, 40, 30));

		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			testCup.fillCoffee(20);
		});
	}
	
}
