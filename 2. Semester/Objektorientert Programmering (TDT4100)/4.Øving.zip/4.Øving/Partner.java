package objectstructures;

public class Partner {
	private Partner partner;
	private String name;
	
	public static void main(String[] args) {
		Partner partner1 = new Partner("Martin");
		Partner partner2 = new Partner("Henrik");
		
		partner1.setPartner(partner2);
		
		
		System.out.println(partner1.getPartner().getName());
		System.out.println(partner2.getPartner().getName());

	}
	 
	public Partner(String argName) {
		this.name = argName;
	}
	
	public String getName() {
		return this.name;
	}
	
	public Partner getPartner() {
		return this.partner;
	}
	
	public void setPartner(Partner argPartner) {
	    if (this.partner == argPartner) {
	        return;
	    }
	    
	    Partner oldPartner = this.partner;
	    this.partner = argPartner;
	    
	    if (oldPartner != null && oldPartner.getPartner() == this) {
	    	oldPartner.setPartner(null);
	    }
	    
	    if (this.partner != null) {
	        this.partner.setPartner(this);
	    }
	}
}
