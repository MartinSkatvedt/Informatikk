package patterns.delegation.office;

import java.util.ArrayList;
import java.util.List;

public class Printer {
	private ArrayList<ArrayList<String>> printHistory = new ArrayList<ArrayList<String>>();
	private List<Employee> users = new ArrayList<Employee>();
	

	public void printDocument(String document, Employee employee) {
		System.out.println(document);
		
		int currentIndex = users.indexOf(employee);
		if (currentIndex < 0) {
			
			users.add(employee);
			printHistory.add(new ArrayList<String>());
			
			currentIndex = users.indexOf(employee);
			printHistory.get(currentIndex).add(document);
		}
		else {
			printHistory.get(currentIndex).add(document);
		}
	}
	
	public List<String> getPrintHistory(Employee employee) {
		int currentIndex = users.indexOf(employee);
		
		if (currentIndex < 0) return new ArrayList<String>();
		else {
			ArrayList<String> printHistoryCopy = new ArrayList<String>(printHistory.get(currentIndex));
			return printHistoryCopy;
		}
	}
}
