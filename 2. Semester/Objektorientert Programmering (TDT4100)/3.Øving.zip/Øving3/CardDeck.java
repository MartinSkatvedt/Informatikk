package encapsulation;

import java.util.Arrays;

public class CardDeck {
	public Card cards[];
	
	public CardDeck(int n) {
		Card tempCards[] = new Card[4*n];
		char suites[] = {'S', 'H', 'D', 'C'};
		int index = 0;
		for (int i = 0; i < suites.length; i++) {
			for (int j = 0; j < n; j++) {
				char suitAtIndex = suites[i];
				tempCards[index] = new Card(suitAtIndex, j+1);
				index++;
			}
		}
		this.cards = tempCards;
	}
	
	public static void main(String[] args) {
		CardDeck m1 = new CardDeck(10);
		m1.shufflePerfectly();
		for (Card card : m1.cards) System.out.println(card);
	}

	
	public int getCardCount() {
		return this.cards.length;
	}
	
	public Card getCard(int n) {
		if (n >= this.getCardCount() || n < 0) throw new IllegalArgumentException("Ugyldig n");
		else return this.cards[n];
	}
	
	public void shufflePerfectly() {
		
		int cardsLength = this.getCardCount();
		
		Card partOne[] = Arrays.copyOfRange(this.cards, 0, cardsLength/2 );
		Card partTwo[] = Arrays.copyOfRange(this.cards, cardsLength/2 , cardsLength);
		Card[] splitDeck[] = {partOne, partTwo};
		
		Card shuffledCards[] = new Card[cardsLength];
		int index = 0;
		for (int i = 0; i < cardsLength/2; i++) {
			for (int j = 0; j < 2; j++) {
				shuffledCards[index] = splitDeck[j][i];
				index++;
			}
			
		}
		this.cards = shuffledCards;
	}
}

