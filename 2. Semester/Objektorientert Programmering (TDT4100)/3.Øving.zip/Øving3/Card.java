package encapsulation;

public class Card {
	private char suit;
	private int face;
	
	
	public Card(char argSuit, int argFace) {
		if (validateFace(argFace)) this.face = argFace;
		if (validateSuit(argSuit)) this.suit = argSuit;
	}
	
	
	private boolean validateFace(int argFace) {
		if (argFace <= 0 || argFace > 13) {
			throw new IllegalArgumentException("Tall m� v�re mellom 1 og 13");
		}
		else return true;
	}
	
	private boolean validateSuit(char argSuit) {
		switch (argSuit) {
		case 'S':
			return true;
		case 'H':
			return true;
		case 'D':
			return true;
		case 'C':
			return true;
		default:
			throw new IllegalArgumentException("Ugyldig korttype");
		}
	}
	
	public char getSuit() {
		return this.suit;
	}
	
	public int getFace() {
		return this.face;
	}
	
	public String toString() {
		return "" + this.suit +  + this.face + "";

	}
}
