# Del 2- Innkapsling og Objektstrukturer

Fyll inn set og get-metodene i [Person](Person.java)-klassen. 
Du skal gjera dette utan å endra kode i [Address](Address.java)-klassen.