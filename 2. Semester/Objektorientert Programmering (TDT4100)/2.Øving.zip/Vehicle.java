package encapsulation;

public class Vehicle {
	private char kjoretoy;
	private char drivstoff;
	private String regNr;
	
	public static void main(String[] args) {}
	
	public Vehicle(char kjoretoyArg, char drivstoffArg, String regNrArg) {
		if (kjoretoyValidator(kjoretoyArg)) this.kjoretoy = kjoretoyArg;
		else throw new IllegalArgumentException("Bad vehicle type)");
		
		if (divstoffValidator(drivstoffArg)) this.drivstoff = drivstoffArg;
		else throw new IllegalArgumentException("Bad fuel type");
		
		
		registrationNumberValidator(regNrArg);
		this.regNr = regNrArg;
		
	}
	
	public char getFuelType() {
		return this.drivstoff;
	}
	
	public String getRegistrationNumber() {
		return this.regNr;
	}
	
	public char getVehicleType() {
		return this.kjoretoy;
	}
	
	public void setRegistrationNumber(String nyttRegNr) {
		registrationNumberValidator(nyttRegNr);
		this.regNr = nyttRegNr;
	}
	
	private boolean kjoretoyValidator(char kjoretoyArg) {
		if (kjoretoyArg == 'M') return true;
		if  (kjoretoyArg == 'C') return true;
		else return false;
	}
	
	private boolean divstoffValidator(char drivstoffArg) {
		switch (drivstoffArg) {
		case 'H':
			if (this.kjoretoy == 'C') return true;
			else return false;
		case 'E':
			return true;
		case 'D':
			return true;
		case 'G':
			return true;
		default: 
			return false;
			
		}
	}
	
	private void registrationNumberValidator(String regNrArg) {
		String RegNrBokstaver = regNrArg.substring(0, 2);
		String RegNrTall = regNrArg.substring(2);
		
		//Sjekk antall tall
		if (this.kjoretoy == 'M' && RegNrTall.length() != 4) throw new IllegalArgumentException("M� v�re 4 tall p� motorsykler");
		if (this.kjoretoy == 'C' && RegNrTall.length() != 5) throw new IllegalArgumentException("M� v�re 5 tall p� biler");

		//M� v�re store bokstaver
		//��� kan ikke v�re bokstaver 
		for (int i = 0; i < RegNrBokstaver.length(); i++) {
			char currentBokstav = RegNrBokstaver.charAt(i);
			if (!Character.isLetter(currentBokstav)) throw new IllegalArgumentException("Bokstaver m� v�re bokstaver");
			if (!Character.isUpperCase(currentBokstav)) throw new IllegalArgumentException("Bokstaver m� v�re store");
			if (currentBokstav == '�' || currentBokstav == '�' || currentBokstav == '�') throw new IllegalArgumentException("Ugyldige bokstaver");
		}
		
		for (int i = 0; i < RegNrTall.length(); i++) {
			char currentDigit = RegNrTall.charAt(i);
			if (!Character.isDigit(currentDigit)) throw new IllegalArgumentException("Tall m� v�re tall");
			
		}
		
		//Sjekke om bokstaver er EL eller EK og om bilen er elbil
		//Sjekke om bokstaver HY 
		switch(this.drivstoff) {
			case 'H':
				if (!(regNrArg.startsWith("HY"))) throw new IllegalArgumentException("Hydrogenbilskilt uten hydrogenbil");
				break;
			case 'E':
				if (!(regNrArg.startsWith("EL") || regNrArg.startsWith("EK"))) throw new IllegalArgumentException("Elbilskilt uten elbil");
				break;
			case 'D':
				if (regNrArg.startsWith("EL") || regNrArg.startsWith("EK") || regNrArg.startsWith("HY")) throw new IllegalArgumentException("Dieselbil med feil skilt");
				break;
			case 'G':
				if (regNrArg.startsWith("EL") || regNrArg.startsWith("EK") || regNrArg.startsWith("HY")) throw new IllegalArgumentException("Bensinbil med feil skilt");
				break;
			default:
				break;
		}
		
	}
}
