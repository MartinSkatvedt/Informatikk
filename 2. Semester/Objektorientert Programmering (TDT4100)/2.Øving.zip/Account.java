package encapsulation;

public class Account {
	public double balance = 0;
	public double interestRate = 0;
	
	public static void main(String[] args) {}
	
	public Account(double newBalance, double newInterestRate) {
		if (newBalance > 0) this.balance = newBalance;
		else this.throwError("Kan ikke b�re negativt tall");
		if (newInterestRate > 0) this.interestRate = newInterestRate;
		else this.throwError("Kan ikke b�re negativt tall");
	}
	
	
	public double getBalance() {
		return this.balance;
	}
	
	public double getInterestRate() {
		return this.interestRate;
	}
	
	
	public void setInterestRate(double newInterestRate) {
		if (newInterestRate >= 0) this.interestRate = newInterestRate;
		else this.throwError("Kan ikke b�re negativt tall");;
	}
	
	
	public void deposit(double addValue) {
		if (addValue >= 0 ) this.balance += addValue;
		else this.throwError("Kan ikke b�re negativt tall");;
	}
	
	public void withdraw(double withdrawAmount) {
		if (withdrawAmount <= 0) this.throwError("Kan ikke b�re negativt tall");;
		if (this.balance - withdrawAmount < 0) throwError("Du overbeslater konto");
		else this.balance -= withdrawAmount;
	}
	
	public void addInterest() {
		this.balance += this.balance * (this.interestRate/100);
	}
	
	
	public String toString() {
		return "[balance=" + this.balance + " interest rate=" + this.interestRate + "]";

	}
	
	private void throwError(String errorMessage) {
		throw new IllegalArgumentException(errorMessage);
	}
	
}
