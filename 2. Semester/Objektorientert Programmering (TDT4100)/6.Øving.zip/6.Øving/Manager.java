package patterns.delegation.office;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.function.BinaryOperator;


public class Manager implements Employee {
	private Collection<Employee> employees;
    private Iterator<Employee> employeeIterator;
	private int nTasks = 0;

	
	public static void main(String[] args) {
		Printer printer1 = new Printer();
		Collection<Employee> clerks = new ArrayList<Employee>();
		
		for (int i = 0; i < 2; i++) {
			clerks.add(new Clerk(printer1));
		}
		
		Manager managerSolo = new Manager(clerks);
		managerSolo.doCalculations((x,y) -> x+y, 2.0, 3.5);
		managerSolo.doCalculations((x,y) -> x+y, 2.0, 3.5);
		managerSolo.doCalculations((x,y) -> x+y, 2.0, 3.5);

		System.out.println("Efficiency simple hierarchy: " + (double)managerSolo.getTaskCount()/(double)managerSolo.getResourceCount());
		
		/*------------------------------------------------------*/
		Collection<Employee> clerks1 = new ArrayList<Employee>();
		Collection<Employee> clerks2 = new ArrayList<Employee>();

		
		for (int i = 0; i < 2; i++) {
			clerks1.add(new Clerk(printer1));
			clerks2.add(new Clerk(printer1));
		}
		
		
		Manager manager1 = new Manager(clerks1);
		Manager manager2 = new Manager(clerks2);
		
		Collection<Employee> managers = new ArrayList<Employee>();
		managers.add(manager1);
		managers.add(manager2);
		
		Manager topManager = new Manager(managers);
		topManager.doCalculations((x,y) -> x+y, 2.0, 3.5);
		topManager.doCalculations((x,y) -> x+y, 2.0, 3.5);
		topManager.doCalculations((x,y) -> x+y, 2.0, 3.5);

		
		System.out.println("Efficiency for complex hierarchy " + (double)topManager.getTaskCount()/(double)topManager.getResourceCount());
	}

	public Manager (Collection<Employee> employees) {
		if (employees.size() == 0) throw new IllegalArgumentException("Must have employees");
		
		this.employees = employees;
		employeeIterator = employees.iterator();	
	}

	@Override
	public int getResourceCount() {
		int total = 1;
		for (Employee employee: this.employees) {
			total += employee.getResourceCount();
		}
		return total;
	}

	@Override
	public int getTaskCount() {
		return this.nTasks;
	}

	private Employee getNextEmployee() {
		if (this.employeeIterator.hasNext()) {
			return employeeIterator.next();
		}
		else {
			employeeIterator = employees.iterator();
			return employeeIterator.next();
		}
	}
		
	@Override
	public void printDocument(String document) {
		this.nTasks++;
		this.getNextEmployee().printDocument(document);
	}

	@Override
	public double doCalculations(BinaryOperator<Double> operation, double value1, double value2) {
		this.nTasks++;
		return this.getNextEmployee().doCalculations(operation, value1, value2);
	}
}
