package patterns.delegation.office;

import java.util.function.BinaryOperator;

public interface Employee {
	int getResourceCount();
	int getTaskCount();
	void printDocument(String document);
	double doCalculations(BinaryOperator<Double> operation, double value1, double value2);
}
