let videosHTML = document.getElementsByClassName("videoElement");
let videoArray = Array.from(videosHTML);
let videoTag = document.getElementById("vid");

function Reponsive(x) {
  if (x.matches) {
    videoTag.autoplay = false;
    for (video of videoArray) {
      video.style.display = "none";
    }
  }
}

let x = window.matchMedia("(max-width: 940px)");
Reponsive(x);
x.addListener(Reponsive);
