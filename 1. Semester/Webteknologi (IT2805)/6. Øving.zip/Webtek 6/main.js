incomeElement = document.getElementById("fincome");
wealthElement = document.getElementById("fwealth");
taxElement = document.getElementById("ftax");

incomeElement.addEventListener("keydown", calculateTax);
wealthElement.addEventListener("keydown", calculateTax);

function calculateTax() {
  let income = incomeElement.value;
  let wealth = wealthElement.value;
  let tax = income * 0.35 + 0.25 * wealth;
  taxElement.value = tax.toFixed(2);
}
