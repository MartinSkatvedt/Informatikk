taskInputElement = document.getElementById("taskInput");
taskSubmitElement = document.getElementById("taskSubmit");
todoListElement = document.getElementById("todoList");
outputElementElement = document.getElementById("outputElement");

taskSubmitElement.addEventListener("click", addTask);

let tasks = [];
let totalDone = 0;

function addTask() {
  let liElement = document.createElement("li");
  let text = document.createTextNode(taskInputElement.value);

  let checkboxElement = document.createElement("input");
  checkboxElement.type = "checkbox";

  checkboxElement.onchange = (event) => {
    if (checkboxElement.checked) {
      checkboxElement.parentElement.style.textDecoration = "line-through";
      totalDone += 1;
      updateCounter();
    } else {
      checkboxElement.parentElement.style.textDecoration = "none";
      totalDone -= 1;
      updateCounter();
    }
  };

  liElement.appendChild(checkboxElement);
  liElement.appendChild(text);

  todoListElement.insertBefore(liElement, todoListElement.childNodes[0]);

  tasks.push({
    task: taskInputElement.value,
    timestamp: Date.now(),
  });
  updateCounter();
  taskInputElement.value = "";
}

function updateCounter() {
  outputElementElement.innerText =
    totalDone + "/" + tasks.length + " tasks completed";
}
