/* Part 2 */
console.log("PART 2");

for (let i = 1; i < 21; i++) {
  //standard for loop
  console.log(i);
}

/* Part 3 */
console.log("PART 3");

const numbers = [
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  12,
  13,
  14,
  15,
  16,
  17,
  18,
  19,
  20,
];

for (let i of numbers) {
  //Checks first if the number is dividable with both 3 and 5
  if (i % 3 == 0 && i % 5 == 0) {
    console.log("Eplekake");
  } else if (i % 3 == 0) {
    console.log("Eple");
  } else if (i % 5 == 0) {
    console.log("Kake");
  } else {
    console.log(i);
  }
}
/* Part 4 */
const titleElement = document.getElementById("title");
titleElement.innerText = "Hello, JavaScript"; //Sets the text of the h1 title element

/* Part 5 */
//Assaigns alle the buttons and the magic div to variables
const magicElement = document.getElementById("magic");
const button_1 = document.getElementById("button1");
const button_2 = document.getElementById("button2");
const button_3 = document.getElementById("button3");

/*
Add eventlisteners to each button and uses the ES6 arrow synatx to create anonymous functions.
This saves space and looks much better. If the functions had been more complex I would have stuck to the normal
syntax.
*/

button_1.addEventListener("click", () => (magicElement.style.display = "none"));

button_2.addEventListener("click", () => {
  magicElement.style.display = "block";
  magicElement.style.visibility = "hidden";
});

button_3.addEventListener("click", () => {
  magicElement.style.display = "block";
  magicElement.style.visibility = "visible";
});

/* Part 6 */
const technologies = [
  "HTML5",
  "CSS3",
  "JavaScript",
  "Python",
  "Java",
  "AJAX",
  "JSON",
  "React",
  "Angular",
  "Bootstrap",
  "Node.js",
];
//gets the list with id="tech" and assign it to the techElement variable
const techElement = document.getElementById("tech");

//loops through the techonologies array
for (let element of technologies) {
  let liElement = document.createElement("li"); //creates li element
  liElement.innerText = element; //set the text of the li element
  techElement.appendChild(liElement); //appends the new child to the ul
}
