print("print() skriver tekst ut på skjerm og skifter linje")
input("input() venter at du skriver noe og slår Enter: ")
print("print() kan ha", "mange tekster", "skilt med komma")
input("input() tillater kun en tekst! OK? ")

print(input("Hei, hva heter du? "), "- det var et fint navn.")

print(input("Navn? "), "- kult navn!")
print(input("favorittfag? "), "- interessant!")

navn = input("Hei, hva heter du?" )
print(navn, "- det var et fint navn.")
print("Lykke til med ITGK,", navn)


navn = input("Navn? ")

print("Hei,", navn)

fag = input("Favorittfag? ")

print(fag, "- interessant!")

print("Ha en fin dag,", navn)

print("- og lykke til med ", fag)

import math
 
# VERSJON 1, uten variable
print("Areal av sirkelen:", math.pi * 5.4**2)
print("Volum av sylinderen:", math.pi * 5.4**2 * 7.9)
 
print()
 
# VERSJON 2, med variable
r = 5.4 # radius for en sirkel
A_sirkel = math.pi * r**2
print("Areal av sirkelen:", A_sirkel)
h = 7.9 # høyde sylinder hvor sirkelen er grunnflate
V_syl = A_sirkel * h
print("Volum av sylinderen:", V_syl)

import math

r = 5.4
h = 7.9
O = math.tau * r
A = math.pi * pow(r, 2)
print("Har en sirkel med radius", 5.4, "som er grunnflate i en sylinder med høyde", 7.9)
print("Omkrets av sirkelen:", round(O, 1))  #tau er det samme som 2 pi
print("Areal av sirkelen:", round(A, 1))
print("Areal av sylinderen:", round((O * h) + (2 * A), 1))

# Eksempel på tilordningssetninger som funker
pokemon_name = "Tyranitar"
MaxCP = 3670
antall = 3
antall = antall + 1      # høyre side regnes ut som 3+1, så 4 blir ny verdi i variabelen antall
resists_fighting = False
level42 = "to be done"   # tall er OK i variabelnavn unntatt helt fremst
  
# Eksempel på tilordninger som IKKE funker
1 = antall              # variabelen må stå på venstre side
antall + 1 = antall     # og v.s. kan KUN inneholde et variabelnavn, ikke et større uttrykk
10kamp = "gøy"          # variabel kan ikke begynne med tall, kun bokstav eller _
antall = 3              # denne er OK, men se neste linje
antall = Antall + 1     # Python skiller mellom store og små bokstaver, Antall vil være en annen
                        # variabel og gir NameError her fordi den ikke er opprettet i en tidligere setning
happy hour = 20         # navn kan ikke inneholde mellomrom, burde vært happy_hour eller happyHour
alkohol% = 4.5          # % kan ikke brukes i variabelnavn (betyr modulo). Samme gjelder andre spesialtegn,
                        # hold deg til vanlige bokstaver og tall

navn = "Per"
idealAlder = 42
kundensAlder = 37  
differanse = idealAlder - kundensAlder
print(navn, "er", differanse, "år unna idealalderen")

navn = "Martin"
alder = 20

print("Jeg heter " + navn +  ", og er", alder, "år.")


