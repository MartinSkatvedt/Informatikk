import random

def pop_random_song(songs):
    return songs.pop(random.randint(0, len(songs) - 1))




def song_conest(songs):
    counter = 0
    totalLen = len(songs)
    while True:
        counter += 1
        songTuple = pop_random_song(songs)
        question = songTuple[0]
        answer = songTuple[1]
        print("The lyrics are:")
        print(question)
        while True:
            userAnswer = input("What is the next word? ")
            if (answer.lower() == userAnswer.lower()):
                print("Correct!")
                break
            else:
                print("Wrong guess. Try again.")

        if (counter == totalLen):
            print("Congratulations, you got every song!")
            break

        if (input("Do you want to go again (y/n) ") == "n"):
            print("Welcome back later :D")
            break

songs = [("You hear the door slam. And realize there's nowhere left to", "run"),
         ("Oh, I wanna dance with somebody. I wanna feel the",  "heat"),
         ("There's a fire starting in my heart. Reaching a fever", "pitch"),
         ("Hey, I just met you and this is crazy. But here's my", "number"),
         ("'Cause baby, you're a firework. Come on, show 'em what you're", "worth")]


print(song_conest(songs))
