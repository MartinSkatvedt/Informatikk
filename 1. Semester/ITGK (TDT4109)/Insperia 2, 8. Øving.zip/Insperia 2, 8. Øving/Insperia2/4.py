def smallify_words(words):
    smallList = []
    for word in words:
        smallList.append(word.lower())
    return smallList


#print(smallify_words(["DOG", "CaT", "screEn"]))


def get_five_objectives():
    while True:
        userInput = input("Enter five objects separated by ; ")
        ordListe = userInput.split(";")

        if (len(ordListe) != 5):
            print("You where supposed to enter FIVE objects not {}".format(len(ordListe)))
        else:
            break

    return smallify_words(ordListe)


def play_game():
    fasit = get_five_objectives()

    while True:
        flag = True
        guess = input("What is your guess? ").lower()

        if (guess == "quit"):
            break
        for i, word in enumerate(fasit):
            if (guess == word):
                flag = False
                print("Congratulations! You remembered {}".format(word))
                fasit.pop(i)

        if (flag):
            print("Sorry that was not one of the words")


        if len(fasit) <= 0:
            print("You remembered all the objects")
            break


play_game()
