
def input_strings():
    liste = []
    for i in range(4):
        liste.append(input("Skriv inn en streng: "))
    return liste



def acronym():
    deler = input_strings()
    akronym = ""
    for ord in deler:
        akronym += ord[0]
    print(akronym.upper())

acronym()
