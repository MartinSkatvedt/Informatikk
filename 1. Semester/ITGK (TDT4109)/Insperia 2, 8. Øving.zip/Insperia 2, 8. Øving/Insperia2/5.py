

def derivative(x, function):
    h = 1e-8
    approx = (function(x + h) - function(x))/h
    return approx


def f(x):
    return pow(x, 2) + 2*x + 13

print(round(derivative(3, f), 2))
