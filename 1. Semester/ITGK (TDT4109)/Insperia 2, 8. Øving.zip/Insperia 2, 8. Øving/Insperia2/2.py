def do_user_like(items):
    returnListe = []
    print("On a scale from 1 to 10 where 10 is the highest, how much do you like: ")
    for item in items:
        tall = 0
        while True:
            tall = int(input( item + "? " ))
            if (tall >= 0 and tall <= 10):
                break;
            else:
                print("You have to give a value in the inerval [1, 10]. Try again")
        returnListe.append((item, tall))

    return returnListe


from operator import itemgetter, attrgetter

def get_prioritized_list(items):
    sortedList = items
    sortedList.sort(reverse=False, key=itemgetter(1))
    sortedList.reverse()
    return sortedList


#get_prioritized_list([ ("Zebra", 10), ("Dogs", 8),("Cats", 8), ])


def what_user_likes(items, num):
    if (num < 1 or num > len(items)):
        print("Invalid number given")
        return -1

    sortedRatedListe = get_prioritized_list(do_user_like(items))

    print("Your top {} are".format(num))
    for i in range(0, num):
        print("{}. {}".format(i+ 1, sortedRatedListe[i][0]))


what_user_likes(["Zebra","Dogs","Cats"], 2)
