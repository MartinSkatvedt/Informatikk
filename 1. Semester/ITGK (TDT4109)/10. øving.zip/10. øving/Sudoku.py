#!/usr/bin/env python
# coding: utf-8

#  <nav class="navbar navbar-default">
#   <div class="container-fluid">
#     <div class="navbar-header">
#       <a class="navbar-brand" href="_Oving10.ipynb">Øving 10</a>
#     </div>
#     <ul class="nav navbar-nav">
#     <li class="active"><a href="Rekursjon.ipynb">Rekursjon (Obligatorisk TDT4109)</a></li>
#     <li ><a href="Matplotlib.ipynb">Matplotlib (Obligatorisk TDT4110)</a></li>
#     <li ><a href="Eksamen%202012.ipynb">Eksamen Python 2012</a></li>
#     <li ><a href="Sudoku.ipynb">Sudoku</a></li>
#     <li ><a href="numpy-arrays%20og%20matplotlib.ipynb">Numpy-arrays og matplotlib (TDT4110)</a></li>
#     <li ><a href="Bokanalyse%20med%20plotting.ipynb">Bokanalyse med plotting (TDT4110)</a></li>
#     <li ><a href="Sjakk.ipynb">Sjakk</a></li>
#     </ul>
#   </div>
# </nav>
# 
# 
# # Sudoku
# 
# **Læringsmål.**
# 
# * Store problemstillinger
# 
# **I denne oppgaven skal du skrive et større program. For denne typen oppgaver kan det være mer praktisk å laste ned python og eventuelt en IDE (Et område man programmerer i på sin egen maskin). Ta derfor en kikk [her](https://docs.google.com/document/d/17tS0maWyzORUsIjmCVEszfqrl2X4By-Cy2Sw3ENG5lA/edit?usp=sharing) før du begynner. Det er fortsatt mulig å gjøre oppgaven i Jupyter dersom du ikke ønsker å jobbe lokalt, selv om det ikke er anbefalt.**
#  
# I denne oppgaven skal vi først lage et sudoku-spill (før vi lager en sudoku-løser om noen år). Om du ikke kjenner reglene til sudoku kan du lese deg opp på de selv [her](https://no.wikipedia.org/wiki/Sudoku). Del 1 tar seg av å lage et spillbart sudoku-brett.
# 
# Du står fritt til å bygge opp brettet slik som du vil, men brettet skal oppfylle følgende krav:
# 
# * Brukeren skal kunne skrive inn et tall i en valgfri celle. Dersom tallet ikke er gyldig, dvs. ikke mellom 1 og 9, skal en feilmelding skrives ut.
# * Brukeren skal ikke kunne fylle inn et tall som allerede finnes i den samme raden, kolonnen eller kvadratet.
# * Brukeren skal kunne slette et tall fra en celle.
# * Hver gang brukeren fyller inn eller sletter et tall skal det nye brettet skrives ut på en fin måte. Et eksempel kan være som vist under (tallene over og ved siden av brettet angir her henholdsvis kolonne- og radnummer).
# * Brukeren skal kunne laste inn et brett fra en tekstfil.
# * Et halvutfylt brett skal kunne lagres til fil, slik at man kan fullføre det senere.
# * Spillet skal skrive ut en hyggelig gratulasjonsmelding dersom man har klart brettet.
# * Alt skal utføres gjennom et brukervennlig grensesnitt. Det vil si at brukeren ikke skal trenge å kalle på funksjonene selv, men at alt gjøres via input eller ved å lese fra/skrive til fil.
# 
# Eksempel på brett:
# >```python
#     0 1 2   3 4 5   6 7 8 
#   +-------+-------+-------+
# 0 | 0 0 6 | 9 0 5 | 0 1 0 |
# 1 | 9 7 0 | 0 1 2 | 3 0 5 |
# 2 | 0 2 0 | 0 0 4 | 8 6 0 |
#   +-------+-------+-------+
# 3 | 5 0 3 | 8 0 0 | 0 2 0 |
# 4 | 0 0 0 | 0 0 0 | 0 0 0 |
# 5 | 0 8 0 | 0 0 1 | 9 0 7 |
#   +-------+-------+-------+
# 6 | 0 5 4 | 1 0 0 | 0 7 0 |
# 7 | 2 0 7 | 4 5 0 | 0 9 3 |
# 8 | 0 6 0 | 7 0 3 | 1 0 0 |
#   +-------+-------+-------+
# ```

# In[8]:


import csv
class Board:
    def __init__(self):
        self.board = self.createBoard(0)
        self.squareBoard = self.createSquareBoard()

    def checkRow(self,y,number):
        for value in self.board[y]:
            if (value == number and number != 0):
                print("Tallet er på samme rad")
                return 0
        return 1

    def checkCol(self, x, number):
        for row in self.board:
            if row[x] == number and number != 0:
                print("Tallet er i samme kolonne")
                return 0
        return 1

    def checkSquare(self, x, y, number):
        rowSquare = x // 3
        colSquare = y // 3

        for value in self.squareBoard[rowSquare * 3 + colSquare]:
            if (value == number and number != 0):
                print("Tallet er i samme rute")
                return 0
        return 1

    def evalMove(self, x, y, number):
        if not (self.checkRow(y, number)) :
            return 0
        elif not(self.checkCol(x, number)):
            return 0
        elif not(self.checkSquare(x, y, number)):
            return 0
        else:
            return 1

    def setNumber(self, x, y, number):
        if x < 0 and x > 8 and y < 0 and y > 8:
            return 0
            print("Du må velge et gyldig kordinat")

        if (number > 0 and number <= 9):
            if self.evalMove(x, y, number):
                self.board[y][x] = number
                self.squareBoard = self.createSquareBoard()
        elif number == 0:
            self.board[y][x] = number
            self.squareBoard = self.createSquareBoard()
        else:
            print("Tallet du prøver å skrive inn er ikke gyldig")


    def createBoard(self, init):
        board = []
        for row in range(9):
            rowArray = []
            for col in range(9):
                rowArray.append(init)
            board.append(rowArray)
        return board

    def createSquareBoard(self):
        squareBoard = []
        for row in range(9):
            rowArray = []
            squareBoard.append(rowArray)

        for i, row in enumerate(self.board):
            rowSquare = i // 3
            for j, value in enumerate(row):
                colSquare = j // 3
                squareBoard[rowSquare * 3 + colSquare].append(value)
        return squareBoard

    def printBoard(self):
        print("       ", end="")
        for number in range(9):
            print(number, "   ", end="")
        print("")



        for i, rows in enumerate(self.board):
            if i % 3 == 0:
                print("   ", end="")
                for n in range(49):
                    print("-", end="")
                print("")
            print(i, " ", end="")
            for j, val in enumerate(rows):
                if j % 3 == 0:
                    print("|",end="")
                print(" ", val, " ", end="")
            print("|",end="")
            print("")

        print("   ", end="")
        for n in range(49):
            print("-", end="")
        print("")

    def saveBoard(self):
        with open("game.csv", "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerows(self.board)

    def loadBoard(self):
        board = []
        with open('game.csv') as csvDataFile:
            csvReader = csv.reader(csvDataFile)
            for row in csvReader:
                board.append(row)

        for i, row in enumerate(board):
            for j, val in enumerate(row):
                board[i][j] = int(val)
        self.board = board


    def checkWin(self):
        for row in self.board:
            for val in row:
                if val == 0:
                    return 0
        print("Gratulerer, du har løst sudokuen!")
        return 1

board = Board()
board.printBoard()
while True:
    command = input("Hva vil du gjøre? (load, save, exit, play) ")
    if command == "play":
        row = int(input("Hvilken rad vil du endre "))
        col = int(input("Hvilken kolonne vil du endre "))
        number = int(input("Hvilket tall vil du skrive inn "))
        board.setNumber(col,row,number)
        board.printBoard()
        print("")
    elif command == "save":
        board.saveBoard()
        print("saved board")
    elif command == "load":
        board.loadBoard()
        print("loaded board")
        board.printBoard()
    elif command == "exit":
        break
    if board.checkWin(): break


# In[ ]:





# In[ ]:




