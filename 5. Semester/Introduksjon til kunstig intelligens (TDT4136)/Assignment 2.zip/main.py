from typing import List
from Map import Map_Obj;

class Node: #Basic nodes, containes, f,g,h, parent and position. 
    f_val = 0
    g_val = 0
    h_val = 0

    pos = []
    parent = None 

    def __init__(self, pos) -> None:
        self.pos = pos


def manhattan_distance(node_1: Node, node_2: Node) -> float: #Heuristic function, takes in 2 nodes
    return abs(node_2.pos[0] - node_1.pos[0]) + abs(node_2.pos[1] - node_1.pos[1])

class AStar: #Main application class. Containes all Astar logic.
    open_nodes = [] #Open set
    closed_nodes = [] #Closed set

    gValues = {} #Dict for finding cheapest gScore

    end_node = None
    map_obj = None

    def isGoal(self, node: Node) -> bool: #Function for determining if we found goal
        return  node.pos == self.end_node.pos

    def generateSuccessors(self, node: Node) -> List[Node]: #Generate neghbours for a node
        successors = []

        for i in range (-1, 2):
            for j in range(-1, 2):
                if abs(i) == abs(j):
                    continue
                new_node = Node([node.pos[0] + i, node.pos[1] + j])
                if self.map_obj.get_cell_value(new_node.pos) > 0:
                    new_node.g_val = node.g_val + manhattan_distance(node, new_node) * self.map_obj.get_cell_value(new_node.pos)
                    new_node.h_val = manhattan_distance(new_node, self.end_node)
                    new_node.f_val = new_node.g_val + new_node.h_val
                    successors.append(new_node)
        return successors

    def retraceSteps(self, node: Node) -> List[Node]: #Generate steps it took to get to the goal
        steps = []
        current_node = node
        
        while current_node.parent:
            steps.append(current_node)
            current_node = current_node.parent
        
        return steps

    def __init__(self, map_obj: Map_Obj) -> None:
        self.map_obj = map_obj
        inital_node = Node(self.map_obj.get_start_pos())
        self.end_node = Node(self.map_obj.get_goal_pos())
        inital_node.g_val = 0
        self.gValues[str(inital_node.pos)] = 0

        inital_node.h_val = manhattan_distance(inital_node, self.end_node)
        inital_node.f_val = inital_node.g_val + inital_node.h_val

        self.open_nodes.append(inital_node)

        while True:
            if len(self.open_nodes) == 0:
                print("Open list is empty, found no solution")
                break

            self.open_nodes.sort(key=lambda x: x.f_val, reverse=True)

            temp = self.open_nodes.pop()
            self.closed_nodes.append(temp)

            if self.isGoal(temp):
                print("Goal found")
                steps = self.retraceSteps(temp)

                for step in steps:
                    if step.pos == self.end_node.pos:
                        continue
                    self.map_obj.set_cell_value(step.pos, 1)
                break

            successors = self.generateSuccessors(temp)

            for i in successors:
                if str(i.pos) not in self.gValues or i.g_val < self.gValues[str(i.pos)]:
                    i.parent = temp
                    self.gValues[str(i.pos)] = i.g_val
                    if i not in self.open_nodes:
                        self.open_nodes.append(i)


def main():
    print("Starting...")
    map_obj = Map_Obj(task=4)
    AStar(map_obj)
    map_obj.show_map()

main()