import math
import matplotlib.pyplot as plt
import numpy as np
import skimage
import utils

def magnitude(fft_im):
    real = fft_im.real
    imag = fft_im.imag
    return np.sqrt(real**2 + imag**2)

def convolve_im(im: np.array,
                kernel: np.array,
                verbose=True):
    """ Convolves the image (im) with the spatial kernel (kernel),
        and returns the resulting image.

        "verbose" can be used for turning on/off visualization
        convolution

        Note: kernel can be of different shape than im.

    Args:
        im: np.array of shape [H, W]
        kernel: np.array of shape [K, K] 
        verbose: bool
    Returns:
        im: np.array of shape [H, W]
    """
    # START YOUR CODE HERE ### (You can change anything inside this block)
    fft = np.fft.fft2(im) #fft

    pad_size = (fft.shape[0] - kernel.shape[0], fft.shape[1] - kernel.shape[1])
    kernel = np.pad(kernel, (((pad_size[0]+1)//2, pad_size[0]//2), ((pad_size[1]+1)//2, pad_size[1]//2)), "constant", constant_values=0)

    fft_kernel = np.fft.fft2(kernel)
    fft_kernel_shifted = np.fft.fftshift(fft_kernel)
    fft_kernel_shifted_magnitude = np.log(magnitude(fft_kernel_shifted) + 1)

    fft_shifted = np.fft.fftshift(fft) #fft with shift to center
    fft_shifted_magnitude = np.log(magnitude(fft_shifted) +1 ) #Image to show magnitude of shifted fft

    fft_filter= fft * fft_kernel 
    fft_filter_magnitude = np.log(magnitude(np.fft.fftshift(fft_filter)) +1 ) 

    fft_ifft = np.fft.ifft2(fft_filter)
    conv_result = np.fft.ifftshift(fft_ifft).real 

    if verbose:
        # Use plt.subplot to place two or more images beside eachother
        plt.figure(figsize=(20, 4))
        # plt.subplot(num_rows, num_cols, position (1-indexed))
        plt.subplot(1, 5, 1)
        plt.imshow(im, cmap="gray")
        plt.subplot(1, 5, 2)
        # Visualize FFT
        plt.imshow(fft_shifted_magnitude)
        plt.subplot(1, 5, 3)
        # Visualize FFT kernel
        plt.imshow(fft_kernel_shifted_magnitude)
        plt.subplot(1, 5, 4)
        # Visualize filtered FFT image
        plt.imshow(fft_filter_magnitude)
        plt.subplot(1, 5, 5)
        # Visualize filtered spatial image
        plt.imshow(conv_result, cmap="gray")

    ### END YOUR CODE HERE ###
    return conv_result, fft_shifted_magnitude, fft_filter_magnitude


if __name__ == "__main__":
    verbose = True  # change if you want

    # Changing this code should not be needed
    im = skimage.data.camera()
    im = utils.uint8_to_float(im)

    # DO NOT CHANGE
    gaussian_kernel = np.array([
        [1, 4, 6, 4, 1],
        [4, 16, 24, 16, 4],
        [6, 24, 36, 24, 6],
        [4, 16, 24, 16, 4],
        [1, 4, 6, 4, 1],
    ]) / 256
    image_gaussian, gaussian_before, gaussian_after = convolve_im(im, gaussian_kernel, verbose)

    # DO NOT CHANGE
    sobel_horizontal = np.array([
        [-1, 0, 1],
        [-2, 0, 2],
        [-1, 0, 1]
    ])
    image_sobelx, sobelx_before, sobelx_after = convolve_im(im, sobel_horizontal, verbose)

    if verbose:
        plt.show()

    utils.save_im("camera_gaussian.png", image_gaussian)
    utils.save_im("camera_gaussian_before.png", gaussian_before)
    utils.save_im("camera_gaussian_after.png", gaussian_after)

    utils.save_im("camera_sobelx.png", image_sobelx)
    utils.save_im("camera_sobelx_before.png", sobelx_before)
    utils.save_im("camera_sobelx_after.png", sobelx_after)
