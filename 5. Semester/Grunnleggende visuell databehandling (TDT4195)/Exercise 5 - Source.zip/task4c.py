import skimage
import skimage.io
import skimage.transform
import os
import numpy as np
import utils
import matplotlib.pyplot as plt

def magnitude(fft_im):
    real = fft_im.real
    imag = fft_im.imag
    return np.sqrt(real**2 + imag**2)


if __name__ == "__main__":
    # DO NOT CHANGE
    impath = os.path.join("images", "noisy_moon.png")
    im = utils.read_im(impath)

    # START YOUR CODE HERE ### (You can change anything inside this block)
    
    fft = np.fft.fft2(im)
    fft_shifted = np.fft.fftshift(fft)
    fft_shifted_magnitude = np.log(magnitude(fft_shifted) + 1)

    mask = np.ones_like((fft))
    treshold = 9.0 
    for row in range(0, fft.shape[0]):
        for col in range(0, fft.shape[1]):
            if fft_shifted_magnitude[row][col] >= treshold:
                mask[row][col] = 0+0j 

    fft_filtered = fft * np.fft.ifftshift(mask) 
    fft_filtered_shifted = np.fft.fftshift(fft_filtered)
    fft_filtered_shifted_magnitude = magnitude(fft_filtered_shifted)
    fft_filtered_image = np.fft.ifft2(fft_filtered).real


    im_filtered = fft_filtered_image 

    plt.figure(figsize=(25, 5))
    # plt.subplot(num_rows, num_cols, position (1-indexed))
    plt.subplot(1, 5, 1)
    plt.imshow(im, cmap="gray")
    plt.subplot(1, 5, 2)
    # Visualize FFT
    plt.imshow(fft_shifted_magnitude)
    plt.subplot(1, 5, 3)
    plt.imshow(fft_filtered_shifted_magnitude)
    plt.subplot(1, 5, 4)
    plt.imshow(fft_filtered_image, cmap="gray")
   


    plt.show()


    ### END YOUR CODE HERE ###
    utils.save_im("moon_filtered.png", utils.normalize(im_filtered))