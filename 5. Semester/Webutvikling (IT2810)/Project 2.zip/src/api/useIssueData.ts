import { useQuery } from "@tanstack/react-query";
import { IssueResponseType } from "../types/api";

const useIssueData = (
  projectID: string,
  token: string,
  created_after?: string,
  created_before?: string
) => {
  let url_string = `https://gitlab.stud.idi.ntnu.no/api/v4/projects/${projectID}/issues?private_token=${token}`;
  if (created_after) url_string += `&created_after=${created_after}`;
  if (created_before) url_string += `&created_before=${created_before}`;
  return useQuery<IssueResponseType[]>(["issueQuery", projectID], async () => {
    const response = await fetch(url_string);
    const json = response.json();
    return json;
  });
};

export default useIssueData;
