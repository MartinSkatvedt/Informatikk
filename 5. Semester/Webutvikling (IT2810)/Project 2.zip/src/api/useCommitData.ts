import { useQuery } from "@tanstack/react-query";
import { useContext } from "react";
import { StateContext } from "../state/state";
import { CommitResponseType } from "../types/api";

const useCommitData = () => {
  const { state } = useContext(StateContext);
  const millisecondsInDay = 86400000;
  let url_string = `https://gitlab.stud.idi.ntnu.no/api/v4/projects/${state.repositoryID}/repository/commits?private_token=${state.apiKey}&per_page=100`;
  if (state.startDate) url_string += `&since=${new Date(state.startDate).toLocaleDateString()}`;
  if (state.endDate) url_string += `&until=${new Date(state.endDate + millisecondsInDay).toLocaleDateString()}`;
  return useQuery<CommitResponseType[]>(["commitQuery", state], async () => {
    const response = await fetch(url_string);
    if (response.ok) {
      const json = response.json();
      return json;
    }
    return response.ok;
  });
};

export default useCommitData;
