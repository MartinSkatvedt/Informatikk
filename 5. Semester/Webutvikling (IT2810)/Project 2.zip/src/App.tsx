import UserForm from "./components/userForm/UserForm";
import { Box, Heading, Center, Wrap, Flex } from "@chakra-ui/react";
import Image from "./components/image/image";
import SearchHistory from "./components/searchHistory/SearchHistory";
import Tabination from "./components/tabination/Tab";
import useCommitData from "./api/useCommitData";
import {SkipNavContent } from '@chakra-ui/skip-nav'

function App() {
  const {
    data: commitData,
    isLoading: isCommitLoading,
    isError: isCommitError,
  } = useCommitData();

  return (
    <Box className="App">
		<SkipNavContent/>
      <Image
        source="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/GitLab_logo.svg/2560px-GitLab_logo.svg.png"
        altText="GitLab Logo"
      ></Image>
      <Center>
        <Flex align="center" justify="center" wrap="wrap">
          <UserForm />
          <SearchHistory />
        </Flex>
      </Center>
      <Center>
        <Heading mt="20px">Commits</Heading>
      </Center>
      {isCommitLoading ? (
        <Center>Loading ...</Center>
      ) : !commitData ? (
        <Center>
          Error loading commit data. Wrong repository ID or API key.
        </Center>
      ) : (
        <Tabination />
      )}
    </Box>
  );
}

export default App;
