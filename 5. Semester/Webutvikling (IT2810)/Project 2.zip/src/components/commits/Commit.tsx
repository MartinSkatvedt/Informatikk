import { CommitResponseType } from "../../types/api";
import {
  AccordionButton,
  AccordionIcon,
  AccordionItem,
  AccordionPanel,
  Box,
  Heading,
  Table,
  TableContainer,
  Tbody,
  Td,
  Tr,
} from "@chakra-ui/react";

type CommitProps = {
  commitData: CommitResponseType;
};

const Commit = (props: CommitProps) => {
  const { commitData } = props;
  return (
    <AccordionItem>
      <h2>
        <AccordionButton>
          <Box flex="1" textAlign="left">
            {commitData.title}
          </Box>
          <AccordionIcon />
        </AccordionButton>
      </h2>
      <AccordionPanel pb="4px">
        <TableContainer>
          <Table>
            <Tbody>
              <Tr>
                <Td>id</Td>
                <Td>{commitData.id}</Td>
              </Tr>
              <Tr>
                <Td>Author name</Td>
                <Td>{commitData.author_name}</Td>
              </Tr>
              <Tr>
                <Td>Author email</Td>
                <Td>{commitData.author_email}</Td>
              </Tr>
              <Tr>
                <Td>Authored date</Td>
                <Td>{commitData.authored_date}</Td>
              </Tr>
            </Tbody>
          </Table>
        </TableContainer>
      </AccordionPanel>
    </AccordionItem>
  );
};

export default Commit;
