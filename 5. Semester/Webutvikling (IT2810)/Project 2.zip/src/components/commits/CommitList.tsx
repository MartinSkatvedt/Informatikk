import { Accordion, Heading, Box } from "@chakra-ui/react";
import useCommitData from "../../api/useCommitData";
import Commit from "./Commit";

const CommitList = () => {
  const {
    data: commitData,
    isLoading: isCommitLoading,
    isError: isCommitError,
  } = useCommitData();

  if (!commitData || isCommitLoading || isCommitError)
    return <div>Loading...</div>;

  const CommitElements = Object.keys(commitData).map((key) => (
    <Commit key={key} commitData={commitData[Number(key)]} />
  ));

  return (
    <Box>
      <Heading as="h3" size="md">
        Commit List
      </Heading>
      <Accordion
        w={["87%", "87%", "50%", "50%"]}
        ml="auto"
        mr="auto"
        defaultIndex={[]}
        allowMultiple
      >
        {CommitElements}
      </Accordion>
    </Box>
  );
};

export default CommitList;
