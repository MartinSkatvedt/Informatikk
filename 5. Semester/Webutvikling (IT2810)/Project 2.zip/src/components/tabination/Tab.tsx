import {
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Tab,
  Center,
} from "@chakra-ui/react";
import CommitList from "../commits/CommitList";
import { RepoChart } from "../charts/RepoChart";
import DateRange from "../dateRange/DateRange";
import { SkipNavLink } from "@chakra-ui/skip-nav";

const Tabination = () => {
  return (
    <Tabs variant="soft-rounded" colorScheme="green" align="center">
      <TabList>
        <Tab>List View</Tab>
        <Tab>Graph View</Tab>
      </TabList>
      <DateRange />
      <TabPanels>
        <TabPanel>
          <CommitList />
          <SkipNavLink position="static">Go to top</SkipNavLink>
        </TabPanel>
        <TabPanel>
          <RepoChart />
        </TabPanel>
      </TabPanels>
    </Tabs>
  );
};

export default Tabination;
