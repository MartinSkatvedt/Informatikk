import UserForm from "./UserForm";
import renderer from "react-test-renderer";
import { initialState, StateProvider } from "../../state/state";
import { fireEvent, render, screen } from "@testing-library/react";

test("Snapshot test UserForm.tsx", () => {
  const tree = renderer.create(<UserForm />).toJSON();
  expect(tree).toMatchSnapshot();
});

test("Change value of inputs", async () => {
  render(
    <StateProvider>
      <UserForm />
    </StateProvider>
  );

  expect(
    screen.getByDisplayValue(initialState.repositoryID)
  ).toBeInTheDocument();
  fireEvent.change(screen.getByLabelText("Repository ID"), {
    target: { value: "testText" },
  });
  expect(screen.getByDisplayValue("testText")).toBeInTheDocument();
});
