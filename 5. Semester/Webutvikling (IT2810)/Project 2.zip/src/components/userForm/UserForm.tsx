import {
  FormLabel,
  FormControl,
  FormErrorMessage,
  Input,
  Button,
  Box,
  Center,
} from "@chakra-ui/react";
import { useContext, useEffect } from "react";
import { FieldError, useForm } from "react-hook-form";
import {
  setApiKey,
  setApiKeyHistory,
  setRepoId,
  setRepoIdHistory,
} from "../../state/actions";
import {
  addApiKeyToHistory,
  addRepoIdToHistory,
} from "../../state/webStorageWrapper";
import { StateContext } from "../../state/state";

type FormData = {
  repositoryId: string;
  apiToken: string;
};

const UserForm = () => {
  const { state, dispatch } = useContext(StateContext);

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<FormData>();

  useEffect(() => {
    setValue("repositoryId", state.repositoryID);
    setValue("apiToken", state.apiKey);
  }, [state.apiKey, state.repositoryID]);

  const onSubmit = handleSubmit((data) => {
    dispatch(setRepoId(data.repositoryId));
    dispatch(setApiKey(data.apiToken));
    addRepoIdToHistory(data.repositoryId, (data) =>
      dispatch(setRepoIdHistory(data))
    );
    addApiKeyToHistory(data.apiToken, (data) =>
      dispatch(setApiKeyHistory(data))
    );
  });

  const isInvalidStyle = (error: FieldError | undefined) => {
    return error ? { borderColor: "red" } : {};
  };

  return (
    <Box>
      <form onSubmit={onSubmit}>
        <FormControl isInvalid={errors.repositoryId && true}>
          <FormLabel>Repository ID</FormLabel>
          <Input
            style={isInvalidStyle(errors.repositoryId)}
            {...register("repositoryId", { required: true })}
            defaultValue={state.repositoryID}
          />
          <FormErrorMessage>Repository ID field is required</FormErrorMessage>
        </FormControl>

        <FormControl isInvalid={errors.apiToken && true}>
          <FormLabel htmlFor="apiToken">API Token</FormLabel>
          <Input
            style={isInvalidStyle(errors.apiToken)}
            {...register("apiToken", { required: true })}
            defaultValue={state.apiKey}
          />
          <FormErrorMessage>API token field is required</FormErrorMessage>
        </FormControl>

        <Center>
        <Button mt="5px" type="submit" backgroundColor={"#c6f6d5"} w = "50%">
          Submit
        </Button>
        </Center>
      </form>
    </Box>
  );
};

export default UserForm;
