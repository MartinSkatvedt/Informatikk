import { Image, Box, Center } from "@chakra-ui/react";
import React from "react";

type PictureProps = {
  altText: string;
  source: string;
};
class Picture extends React.Component<PictureProps> {
  render() {
    return (
      <Box w="100%">
        <Center>
          <Image
            src={this.props.source}
            alt={this.props.altText}
            w={{ sm: "700px", md: "500px", lg: "650px" }}
          />
        </Center>
      </Box>
    );
  }
}

export default Picture;
