import {useState, useEffect, useContext} from "react";
import {Bar} from "react-chartjs-2";
import useCommitData from "../../api/useCommitData";
import {
	Chart as ChartJS,
	CategoryScale,
	LinearScale,
	BarElement,
	Tooltip,
} from "chart.js";
import {CommitResponseType} from "../../types/api";
import {Flex, Heading, Button, Box} from "@chakra-ui/react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import {StateContext} from "../../state/state";
import {setEndDate, setStartDate} from "../../state/actions";

export const RepoChart = () => {
	const {state, dispatch} = useContext(StateContext);
	const {startDate, endDate} = state;

	/**
	 * Use commit data hook to retrieve commit data
	 */

	const {
		data: commitData,
		isLoading: isCommitLoading,
		isError: isCommitError,
	} = useCommitData();

	ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip);

	/**
	 * Generate date labels for dates between start date and end date
	 * used to draw x-axis in the chart
	 */

	const generateLabels = (): string[] => {
		const temp = new Array();
		const currentDate = new Date(startDate);
		while (currentDate <= new Date(endDate)) {
			temp.push(new Date(currentDate).toLocaleDateString());
			currentDate.setDate(currentDate.getDate() + 1);
		}
		return temp;
	};

	/**
	 * Save labels in state as user may change dates displayed in chart
	 * and thus the labels will change as well
	 */

	const [labels, setLabels] = useState(generateLabels());

	/**
	 * Change labels listening to changes in startDate and endDate
	 */

	useEffect(() => {
		setLabels(generateLabels);
	}, [state.startDate, state.endDate]);

	/**
	 * Reduces commit data to map with date committed as key
	 * and amount of commits on the given day as value
	 */

	const amountOfCommitsByDate =
		commitData ? commitData?.reduce(
			(
				prev: Record<string, number>,
				{committed_date}: CommitResponseType
			) => {
				let dateString = new Date(committed_date).toLocaleDateString();
				prev[dateString] = prev[dateString] + 1 || 1;
				return prev;
			},
			{}
		) || {} : null;
	/**
	 * Config used for drawing the bar chart
	 */

	const data = {
		labels,
		datasets: [
			{
				label: "Amount of commits",
				backgroundColor: "#fc6d21",
				borderColor: "rgb(255, 99, 132)",
				data: amountOfCommitsByDate,
			},
		],
	};

	return (
		<Flex
			direction="column"
			alignItems="center"
			width="50%"
			w={["85%", "85%", "50%", "50%", "50%"]}
		>
			<Heading as="h3" marginLeft="auto" marginRight="auto" size="md">
				Number of commits by date
			</Heading>
			<Bar data={data} />
		</Flex>
	);
};
