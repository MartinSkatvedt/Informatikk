import { Box, Heading } from "@chakra-ui/react";
import HistoryListElement, {
  HistoryListElementEnum,
} from "./HistoryListElement";

type HistoryElementProps = {
  title: string;
  data: string[];
  type: HistoryListElementEnum;
};

const HistoryElement = (props: HistoryElementProps) => {
  const { title, data, type } = props;

  return (
    <Box border="1px solid #e2e8f0" p="3px" m="5px" borderRadius="4px" w="40%">
      <Heading as="h3" size="md" mb="5px">
        {title}
      </Heading>
      <Box maxH="150px" overflow="auto">
        {data.map((val) => (
          <HistoryListElement key={val} value={val} type={type} />
        ))}
      </Box>
    </Box>
  );
};

export default HistoryElement;
