import { Box, Flex } from "@chakra-ui/react";
import { useContext, useEffect, useState } from "react";
import { setApiKeyHistory, setRepoIdHistory } from "../../state/actions";
import { StateContext } from "../../state/state";
import {
  getApiKeyHistory,
  getRepoIdHistory,
} from "../../state/webStorageWrapper";
import HistoryElement from "./HistoryElement";
import { HistoryListElementEnum } from "./HistoryListElement";

const SearchHistory = () => {
  const { state, dispatch } = useContext(StateContext);
  const { repositoryIdHistory, apiKeyHistory } = state;

  useEffect(() => {
    dispatch(setApiKeyHistory(getApiKeyHistory()));
    dispatch(setRepoIdHistory(getRepoIdHistory()));
  }, []);

  return (
    <Flex justifyContent="center">
      <HistoryElement
        title="Api keys"
        data={apiKeyHistory}
        type={HistoryListElementEnum.API_KEY_TYPE}
      />
      <HistoryElement
        title="Repo ids"
        data={repositoryIdHistory}
        type={HistoryListElementEnum.REPO_ID_TYPE}
      />
    </Flex>
  );
};

export default SearchHistory;
