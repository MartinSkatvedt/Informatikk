import { Box } from "@chakra-ui/react";
import { useContext } from "react";
import { setApiKey, setRepoId } from "../../state/actions";
import { StateContext } from "../../state/state";

export enum HistoryListElementEnum {
  API_KEY_TYPE = "API_KEY_TYPE",
  REPO_ID_TYPE = "REPO_ID_TYPE",
}

type HistoryListElementProps = {
  value: string;
  type: HistoryListElementEnum;
};

const HistoryListElement = (props: HistoryListElementProps) => {
  const { value, type } = props;

  const { dispatch } = useContext(StateContext);

  const handleClick = () => {
    if (type == HistoryListElementEnum.API_KEY_TYPE) {
      dispatch(setApiKey(value));
    }
    if (type == HistoryListElementEnum.REPO_ID_TYPE) {
      dispatch(setRepoId(value));
    }
  };

  return (
    <Box
      _hover={{ color: "teal", background: "lightgrey" }}
      onClick={handleClick}
    >
      {value}
    </Box>
  );
};

export default HistoryListElement;
