import {Box, Flex, Text} from "@chakra-ui/react";
import React, {useContext} from "react";
import {StateContext} from "../../state/state";
import DatePicker from "react-datepicker";
import {setEndDate, setStartDate} from "../../state/actions";

const DateRange = () => {
	const {state, dispatch} = useContext(StateContext);
	const {startDate, endDate} = state;

	return (
			<Flex m="10px" justify="center" wrap="wrap">
				<Box borderRadius='md' bg='#CBD5E0' w={"60"} px={4} h={"50px"} m={2}>
					<Text>
						From date: 
					</Text>
					<DatePicker
						selected={new Date(startDate)}
						onChange={(date: Date) =>
							dispatch(setStartDate(date.getTime()))
						}
						selectsStart
						startDate={new Date(startDate)}
						endDate={new Date(endDate)}
					/>
				</Box>

				<Box borderRadius='md' bg='#CBD5E0' w={"60"} px={4} h={"50px"} m={2}>
					<Text>
						To date: 
					</Text>
					<DatePicker
						selected={new Date(endDate)}
						onChange={(date: Date) =>
							dispatch(setEndDate(date.getTime()))
						}
						selectsEnd
						startDate={new Date(startDate)}
						endDate={new Date(endDate)}
						minDate={new Date(startDate)}
					/>
				</Box>
			</Flex>
	);
};

export default DateRange;
