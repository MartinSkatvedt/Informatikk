export type CommitResponseType = {
  id: string;
  short_id: string;
  title: string;
  author_name: string;
  author_email: string;
  authored_date: string;
  committed_date: string;
  created_at: string;
  message: string;
  web_url: string;
};

export type IssueResponseType = {
  title: string;
  description: string;
};
