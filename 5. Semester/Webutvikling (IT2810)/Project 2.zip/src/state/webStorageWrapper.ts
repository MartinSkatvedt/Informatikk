const REPO_ID_KEY = "repo_id";
const API_KEY_KEY = "api_key";

export const addRepoIdToHistory = (
  repoID: string,
  dispatch: (arg1: string[]) => void
) => {
  let repoIdHistoryArray = getRepoIdHistory();

  if (repoIdHistoryArray && !repoIdHistoryArray.includes(repoID)) {
    repoIdHistoryArray.push(repoID);
  }
  localStorage.setItem(REPO_ID_KEY, repoIdHistoryArray.toString());
  dispatch(repoIdHistoryArray);
};

export const getRepoIdHistory = (): string[] => {
  const repoIdHistory = localStorage.getItem(REPO_ID_KEY);
  if (repoIdHistory) {
    return repoIdHistory.split(",");
  }
  return [];
};

export const addApiKeyToHistory = (
  apiKey: string,
  dispatch: (arg1: string[]) => void
) => {
  let apiKeyHistory = getApiKeyHistory();

  if (apiKeyHistory && !apiKeyHistory.includes(apiKey)) {
    apiKeyHistory.push(apiKey);
  }
  sessionStorage.setItem(API_KEY_KEY, apiKeyHistory.toString());
  dispatch(apiKeyHistory);
};

export const getApiKeyHistory = (): string[] => {
  const apiKeyHistory = sessionStorage.getItem(API_KEY_KEY);
  if (apiKeyHistory) {
    return apiKeyHistory.split(",");
  }
  return [];
};
