export enum ActionEnum {
  SET_REPOSITORY_ID = "SET_REPOSITORY_ID",
  SET_API_KEY = "SET_API_KEY",
  SET_API_KEY_HISTORY = "SET_API_KEY_HISTORY",
  SET_REPOSITORY_ID_HISTORY = "SET_REPOSITORY_ID_HISTORY",
  SET_START_DATE = "SET_START_DATE",
  SET_END_DATE = "SET_END_DATE"
}

type setRepoIdAction = { type: ActionEnum.SET_REPOSITORY_ID; payload: string };
type setApiKeyAction = { type: ActionEnum.SET_API_KEY; payload: string };

type setApiKeyHistoryAction = {
  type: ActionEnum.SET_API_KEY_HISTORY;
  payload: string[];
};
type setRepoIdHistoryAction = {
  type: ActionEnum.SET_REPOSITORY_ID_HISTORY;
  payload: string[];
};

type setStartDateAction = {
  type: ActionEnum.SET_START_DATE,
  payload: number;
}

type setEndDateAction = {
  type: ActionEnum.SET_END_DATE,
  payload: number;
}

export type Actions =
  | setRepoIdAction
  | setApiKeyAction
  | setApiKeyHistoryAction
  | setRepoIdHistoryAction
  | setStartDateAction
  | setEndDateAction;

export const setRepoId = (id: string): setRepoIdAction => ({
  type: ActionEnum.SET_REPOSITORY_ID,
  payload: id,
});

export const setApiKey = (apiKey: string): setApiKeyAction => ({
  type: ActionEnum.SET_API_KEY,
  payload: apiKey,
});

export const setApiKeyHistory = (
  apiKeyHistory: string[]
): setApiKeyHistoryAction => ({
  type: ActionEnum.SET_API_KEY_HISTORY,
  payload: apiKeyHistory,
});

export const setRepoIdHistory = (
  repoIdHistory: string[]
): setRepoIdHistoryAction => ({
  type: ActionEnum.SET_REPOSITORY_ID_HISTORY,
  payload: repoIdHistory,
});

export const setStartDate = (date: number): setStartDateAction => ({
  type: ActionEnum.SET_START_DATE,
  payload: date, 
});

export const setEndDate = (date: number): setEndDateAction => ({
  type: ActionEnum.SET_END_DATE,
  payload: date, 
});