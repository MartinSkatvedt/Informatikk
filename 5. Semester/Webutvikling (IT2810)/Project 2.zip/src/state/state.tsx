import {createContext, Dispatch, ReactNode, useReducer} from "react";
import {ActionEnum, Actions} from "./actions";
import {getApiKeyHistory, getRepoIdHistory} from "./webStorageWrapper";

type State = {
	repositoryID: string;
	apiKey: string;
	repositoryIdHistory: string[];
	apiKeyHistory: string[];
	startDate: number;
	endDate: number;
};

export const initialState: State = {
	repositoryID: "17554",
	apiKey: "glpat-8sQz3QPwjU4UKe_4g_2s",
	repositoryIdHistory: [],
	apiKeyHistory: [],
	startDate: new Date(
		new Date().getFullYear(),
		new Date().getMonth(),
		new Date().getDate() - 30
	).getTime(),
	endDate: new Date().getTime(),
};

const StateReducer = (state: State, action: Actions): State => {
	switch (action.type) {
		case ActionEnum.SET_REPOSITORY_ID:
			return {...state, repositoryID: action.payload};
		case ActionEnum.SET_API_KEY:
			return {...state, apiKey: action.payload};
		case ActionEnum.SET_REPOSITORY_ID_HISTORY:
			return {...state, repositoryIdHistory: action.payload};
		case ActionEnum.SET_API_KEY_HISTORY:
			return {...state, apiKeyHistory: action.payload};
		case ActionEnum.SET_START_DATE:
			return {...state, startDate: action.payload};
		case ActionEnum.SET_END_DATE:
			return {...state, endDate: action.payload};
		default:
			return {...state};
	}
};

type StateContextProps = {
	state: State;
	dispatch: Dispatch<Actions>;
};

const initialContext: StateContextProps = {
	state: initialState,
	dispatch: () => null,
};

export const StateContext = createContext<StateContextProps>(initialContext);

type StateProviderProps = {
	children: ReactNode;
};

export const StateProvider = (props: StateProviderProps) => {
	const {children} = props;
	const [state, dispatch] = useReducer(StateReducer, initialState);

	return (
		<StateContext.Provider value={{state, dispatch}}>
			{children}
		</StateContext.Provider>
	);
};
