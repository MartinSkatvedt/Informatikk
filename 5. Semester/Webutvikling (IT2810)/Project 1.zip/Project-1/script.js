$(document).ready(() => {
  let docState = false;
  let grassColor = "green";

  let startAngle = 150;
  const docButton = $("#documentationButton");
  const docSection = $("#documentationSection");
  const myCanvas = $("#myCanvas");

  const grassElement = $("#grassElement");
  const ctx = myCanvas[0].getContext("2d");

  docButton.click(() => {
    if (docState) {
      docSection[0].style.display = "none";
      docButton.html("Trykk for å vise dokumentasjon");
      docState = false;
    } else {
      docSection[0].style.display = "block";
      docButton.html("Trykk for å skjule dokumentasjon");
      docState = true;
    }
  });

  grassElement.hover(
    () => {
      grassElement[0].style.fill = "brown";
    },
    () => {
      grassElement[0].style.fill = "green";
    }
  );

  setInterval(() => {
    startAngle -= 1;
    if (startAngle <= 0) startAngle = 360;
    clearCanvas();
    drawCanvas();
  }, 10);

  const degtorat = (deg) => {
    return (deg / 180) * Math.PI;
  };

  myCanvas.mousemove((event) => {
    let mx = event.clientX - myCanvas.position().left + window.scrollX;
    let my = event.clientY - myCanvas.position().top + window.scrollY;

    if (my > 315 && my < 400 && mx > 0 && mx < 400) {
      grassColor = "brown";
    } else grassColor = "green";
  });

  myCanvas.mouseleave(() => {
    grassColor = "green";
  });
  const drawCanvas = () => {
    ctx.fillStyle = "blue";
    ctx.fillRect(0, 0, 400, 400);

    ctx.fillStyle = "rgb(100, 0, 100)";
    ctx.fillRect(50, 200, 300, 75);

    ctx.fillStyle = grassColor;
    ctx.fillRect(0, 315, 400, 100);

    ctx.fillStyle = "black";
    ctx.beginPath();
    ctx.arc(110, 275, 40, 0, 2 * Math.PI);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "black";
    ctx.beginPath();
    ctx.arc(290, 275, 40, 0, 2 * Math.PI);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "red";
    ctx.beginPath();
    ctx.arc(
      110,
      275,
      40,
      degtorat(startAngle),
      degtorat(startAngle) + (1 / 12) * 2 * Math.PI
    );
    ctx.lineTo(110, 275);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "red";
    ctx.beginPath();
    ctx.arc(
      290,
      275,
      40,
      degtorat(startAngle),
      degtorat(startAngle) + (1 / 12) * 2 * Math.PI
    );
    ctx.lineTo(290, 275);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.fillStyle = "rgb(183, 215, 0)";
    ctx.arc(0, 0, 75, 0, 2 * Math.PI);
    ctx.fill();

    ctx.fillStyle = "rgb(121, 7, 104)";
    ctx.beginPath();
    ctx.moveTo(50, 200);
    ctx.lineTo(150, 130);
    ctx.lineTo(350, 130);
    ctx.lineTo(350, 200);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "rgb(43,179,95)";
    ctx.beginPath();
    ctx.moveTo(80, 185);
    ctx.lineTo(150, 135);
    ctx.lineTo(150, 185);
    ctx.closePath();
    ctx.fill();
  };
  const clearCanvas = () => {
    ctx.clearRect(0, 0, 400, 400);
  };
  drawCanvas();
});
