import numpy as np
import pandas as pd


class Node:
    children: dict = {}
    feature: str = None
    label: str = None

    def __init__(self, feature: str, label: str):
        self.feature = feature
        self.label = label
        self.children = {}

    def add_child(self, value: str, node):
        self.children[value] = node


class DecisionTree:
    tree = None
    positive = ""
    negative = ""
    most_common_label = None

    # Hyperparameters
    max_depth = None
    min_samples_split = None
    min_samples_leaf = None

    def __init__(
        self,
        positive="Yes",
        negative="No",
        max_depth=None,
        min_samples_split=2,
        min_samples_leaf=1,
    ):
        # NOTE: Feel free add any hyperparameters
        # (with defaults) as you see fit
        self.positive = positive
        self.negative = negative

        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.min_samples_leaf = min_samples_leaf

    def split(self, X: pd.DataFrame, attribute: str, value: str) -> pd.DataFrame:
        """
        Splits the given dataframe on the given attribute value

        Args:
            X (pd.DataFrame): a matrix with discrete value where
                each row is a sample and the columns correspond
                to the features.
            attribute (str): the attribute to split on
            value (str): the value of the attribute to split on

        Returns:
            A dataframe with the same columns as X where the given
            attribute has been filtered on the given value
        """
        return X[X[attribute] == value]

    def split_and_remove_col(
        self, X: pd.DataFrame, attribute: str, value: str
    ) -> pd.DataFrame:
        """
        Splits the given dataframe on the given attribute value
        and removes the attribute column

        Args:
            X (pd.DataFrame): a matrix with discrete value where
                each row is a sample and the columns correspond
                to the features.
            attribute (str): the attribute to split on
            value (str): the value of the attribute to split on

        Returns:
            A dataframe with the same columns as X where the given
            attribute has been filtered on the given value and
            the attribute column has been removed
        """
        return X[X[attribute] == value].drop(columns=attribute)

    def get_label_counts(self, y: pd.Series) -> tuple:
        """
        Computes the number of positive and negative labels

        Args:
            y (pd.Series): a vector of discrete ground-truth labels

        Returns:
            A tuple (pos_count, neg_count) where pos_count is the
            number of positive labels and neg_count is the number
            of negative labels
        """
        y_count = y.value_counts()
        return y_count.get(self.positive, 0), y_count.get(self.negative, 0)

    def fit(self, X: pd.DataFrame, y: pd.Series):
        """
        Generates a decision tree for classification

        Args:
            X (pd.DataFrame): a matrix with discrete value where
                each row is a sample and the columns correspond
                to the features.
            y (pd.Series): a vector of discrete ground-truth labels
        """

        self.tree = self.ID3(X, y)

    def best_attribute_from_information_gain(
        self, X: pd.DataFrame, y: pd.Series
    ) -> str:
        """
        Computes the best attribute to split on using information gain

        Args:
            X (pd.DataFrame): a matrix with discrete value where
                each row is a sample and the columns correspond
                to the features.
            y (pd.Series): a vector of discrete ground-truth labels

        Returns:
            The name of the attribute with the highest information gain
        """

        positive_count, negative_count = self.get_label_counts(y)
        S = entropy(np.array([positive_count, negative_count]))

        attribute_gains = {}
        for attribute in X.columns:
            attribute_values = X[attribute].unique()

            attribute_gain = S
            for value in attribute_values:
                # select rows with attribute value
                attribute_rows = self.split(X, attribute, value)
                attribute_rows_y = y[attribute_rows.index]
                positive_count, negative_count = self.get_label_counts(attribute_rows_y)

                attribute_value_entropy = entropy(
                    np.array([positive_count, negative_count])
                )

                attribute_gain -= (
                    len(attribute_rows_y) / len(y)
                ) * attribute_value_entropy

            attribute_gains[attribute] = attribute_gain

        return max(attribute_gains, key=attribute_gains.get)

    def ID3(self, X: pd.DataFrame, y: pd.Series, depth=0):
        """
        Generates a decision tree for classification

        Args:
            X (pd.DataFrame): a matrix with discrete value where
                each row is a sample and the columns correspond
                to the features.
            y (pd.Series): a vector of discrete ground-truth labels
            depth (int): the current depth of the tree
        """  #
        positive_count, negative_count = self.get_label_counts(y)

        if X.empty:
            return Node(None, self.most_common_label)
        if positive_count == 0 and negative_count > 0:
            return Node(None, self.negative)
        if negative_count == 0 and positive_count > 0:
            return Node(None, self.positive)
        if depth == self.max_depth:
            return Node(
                None,
                self.positive if positive_count > negative_count else self.negative,
            )
        if len(X) < self.min_samples_split:
            return Node(
                None,
                self.positive if positive_count > negative_count else self.negative,
            )

        best_attribute = self.best_attribute_from_information_gain(X, y)
        best_node = Node(best_attribute, None)

        attribute_values = X[best_attribute].unique()

        # Check for min_samples_leaf
        for value in attribute_values:
            xs = self.split_and_remove_col(X, best_attribute, value)
            if len(xs) < self.min_samples_leaf:
                return Node(
                    None,
                    self.positive if positive_count > negative_count else self.negative,
                )

        for value in attribute_values:
            xs = self.split_and_remove_col(X, best_attribute, value)
            ys = y[xs.index]

            best_node.add_child(value, self.ID3(xs, ys, depth + 1))

        return best_node

    def predict(self, X: pd.DataFrame):
        """
        Generates predictions

        Note: should be called after .fit()

        Args:
            X (pd.DataFrame): an mxn discrete matrix where
                each row is a sample and the columns correspond
                to the features.

        Returns:
            A length m vector with predictions
        """

        def predict_row(row: pd.Series):
            current_node = self.tree
            while True:
                if current_node.label is not None:
                    return current_node.label
                else:
                    attribute = current_node.feature
                    value = row[attribute]
                    current_node = current_node.children.get(value, None)
                    if current_node is None:
                        return self.most_common_label

        predictions = []
        for index, row in X.iterrows():
            predictions.append(predict_row(row))

        return np.array(predictions)

    def get_rules(self):
        """
        Returns the decision tree as a list of rules

        Each rule is given as an implication "x => y" where
        the antecedent is given by a conjuction of attribute
        values and the consequent is the predicted label

            attr1=val1 ^ attr2=val2 ^ ... => label

        Example output:
        >>> model.get_rules()
        [
            ([('Outlook', 'Overcast')], 'Yes'),
            ([('Outlook', 'Rain'), ('Wind', 'Strong')], 'No'),
            ...
        ]
        """
        # TODO: Implement
        rules = []

        def get_rules_recursive(node: Node, rule: list):
            if node.label is not None:
                rules.append((rule, node.label))
            else:
                for value in node.children:
                    get_rules_recursive(
                        node.children[value], rule + [(node.feature, value)]
                    )

        get_rules_recursive(self.tree, [])

        return rules


# --- Some utility functions


def accuracy(y_true, y_pred):
    """
    Computes discrete classification accuracy

    Args:
        y_true (array<m>): a length m vector of ground truth labels
        y_pred (array<m>): a length m vector of predicted labels

    Returns:
        The average number of correct predictions
    """
    assert y_true.shape == y_pred.shape
    return (y_true == y_pred).mean()


def entropy(counts: np.ndarray):
    """
    Computes the entropy of a partitioning

    Args:
        counts (array<k>): a lenth k int array >= 0. For instance,
            an array [3, 4, 1] implies that you have a total of 8
            datapoints where 3 are in the first group, 4 in the second,
            and 1 one in the last. This will result in entropy > 0.
            In contrast, a perfect partitioning like [8, 0, 0] will
            result in a (minimal) entropy of 0.0

    Returns:
        A positive float scalar corresponding to the (log2) entropy
        of the partitioning.

    """
    assert (counts >= 0).all(), "counts should be non-negative"
    probs = counts / counts.sum()
    probs = probs[probs > 0]  # Avoid log(0)
    return -np.sum(probs * np.log2(probs))
