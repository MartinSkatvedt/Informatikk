import pandas as pd
import numpy as np
from math import pow, exp
import matplotlib.pyplot as plt

class Perceptron:

    #Initalizing perceptron with n_weights weights 
    def __init__(self, n_weights = 2):
        self.weights = np.random.rand(n_weights)
        self.bias = np.random.rand()

    #Hardlim transfer function
    def hardlim(self, x: float) -> int:
        return 0 if x < 0 else 1

    def error(self, y_true : float, y_pred : float) -> float:
        return y_true - y_pred

    #Predicting a single row
    def predict(self, x : np.ndarray) -> int:
        #Calculating weighted sum
        weighted_sum = np.dot(x, self.weights) + self.bias
        return self.hardlim(weighted_sum)
    
    #Predicting a batch of rows
    def predict_batch(self, xs : pd.DataFrame) -> np.ndarray:
        return np.array([self.predict(x) for x in xs.values])
    
    #Fitting the perceptron to the data
    def fit(self, xs: pd.DataFrame, y : pd.Series, epochs : int = 100):
        #Iterating over the epochs
        for epoch in range(epochs):
            print(f'Epoch {epoch}')
            epoch_loss = 0.0
            #Iterating over the rows in the data
            for row in range(len(xs)):
                x = xs.iloc[row].values
                
                #Predicting the row
                y_pred = self.predict(x)
                y_true = y.iloc[row]

                #Calculating loss
                loss = self.error(y_true, y_pred)
                epoch_loss += loss
         
                #Updating the weights and bias
                self.weights = self.weights + loss * x
                self.bias = self.bias + loss


            #Printing the loss for the epoch
            print(f'Loss: {epoch_loss / len(xs)}')
            


def OR():
    #Data for OR-model
    or_data = pd.DataFrame([[0, 0, 0], [0, 1, 1], [1, 0, 1], [1,1,1]], columns=['x0', 'x1', 'y'])
    
    xs = or_data[['x0', 'x1']]
    ys = or_data['y']

    percept = Perceptron(2)
    percept.fit(xs, ys, epochs=10)
    predictions = percept.predict_batch(xs)

    plt.scatter(xs['x0'], xs['x1'], c=predictions)
    plt.title("OR-data")
    plt.savefig("images/or.png")
    plt.show()


def AND():
    #Data for AND-model
    and_data = pd.DataFrame([[0, 0, 0], [0, 1, 0], [1, 0, 0], [1,1,1]], columns=['x0', 'x1', 'y'])

    xs = and_data[['x0', 'x1']]
    ys = and_data['y']

    percept = Perceptron(2)
    percept.fit(xs, ys, epochs=10)
    predictions = percept.predict_batch(xs)


    plt.scatter(xs['x0'], xs['x1'], c=predictions)
    plt.title("AND-data")
    plt.savefig("images/and.png")
    plt.show()

def main():
    #Provided data
    data = pd.read_csv("data.csv")
    data.rename(columns={'# x0': 'x0'}, inplace=True)

    #Transforming data, to make it linearly seperable
    """
    data['x0'] = np.power(data['x0'], 2)
    data['x1'] = np.power(data['x1'], 2)

    plt.scatter(data['x0'], data['x1'], c=data['y'])
    plt.savefig("images/transformed_data.png")
    plt.show()
    """

    #Splitting data into xs and ys
    xs = data[['x0', 'x1']]
    ys = data['y']

    #Creating perceptron
    percept = Perceptron(2)

    #Fitting the perceptron, with a learning rate and n_epochs
    percept.fit(xs, ys, epochs=100)

    #Predicting the data
    predictions = percept.predict_batch(xs)


    #Plotting data
    plt.scatter(xs['x0'], xs['x1'], c=predictions)

    #Plot decision boundary
    x = np.linspace(-1, 1, 10)
    y = - percept.weights[0] / percept.weights[1] * x - percept.bias / percept.weights[1]
    plt.plot(x, y, '-r', label='Decision Boundary')
    plt.legend()
    plt.title("Data")
    plt.savefig("images/data_predictions.png")
    plt.show()


if __name__ == "__main__":
    OR()
    AND()
    main()